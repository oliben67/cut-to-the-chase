<#
CTTC Windows client test bundle -- connects to an already-deployed remote
CTTC server over SSH. No Docker, uv, or Python is needed on this machine;
that's the whole point of this test (see docs/architecture/remote-server.md
in the main repo). This script only needs Node.js + npm and Windows' builtin
OpenSSH client.

Usage: right-click this file -> "Run with PowerShell", or from a PowerShell
prompt:  powershell -ExecutionPolicy Bypass -File .\setup.ps1
#>

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$appDir = Join-Path $root "app"
$keyPath = Join-Path $root "keys\cttc_windows_test"
$cttcDir = Join-Path $env:USERPROFILE ".cttc"
$configPath = Join-Path $cttcDir "connection.json"

function Fail($msg) {
  Write-Host ""
  Write-Host "ERROR: $msg" -ForegroundColor Red
  Write-Host ""
  Read-Host "Press Enter to close"
  exit 1
}

Write-Host "== CTTC Windows client test setup ==" -ForegroundColor Cyan

# 1) prerequisites -----------------------------------------------------------
$node = Get-Command node -ErrorAction SilentlyContinue
$npm  = Get-Command npm  -ErrorAction SilentlyContinue
if (-not $node -or -not $npm) {
  Fail "Node.js/npm not found on PATH. Install it from https://nodejs.org/ (LTS) and re-run this script."
}
Write-Host "Node.js: $(node --version)   npm: $(npm --version)"

$ssh = Get-Command ssh -ErrorAction SilentlyContinue
if (-not $ssh) {
  Fail ("OpenSSH client not found on PATH. On Windows 10/11 it's normally a Windows " +
        "feature: Settings -> Apps -> Optional features -> Add a feature -> ""OpenSSH " +
        "Client"" (or run, as Administrator: Add-WindowsCapability -Online -Name " +
        "OpenSSH.Client~~~~0.0.1.0), then re-run this script.")
}
Write-Host "ssh: $($ssh.Source)"

if (-not (Test-Path $keyPath)) {
  Fail "Bundled SSH key not found at $keyPath -- the zip may be incomplete."
}

# 2) fix the private key's permissions ---------------------------------------
# Windows' OpenSSH client refuses a private key that isn't restricted to the
# current user only (its equivalent of `chmod 600`) -- without this step,
# the first connection attempt fails with "UNPROTECTED PRIVATE KEY FILE".
Write-Host "Restricting key file permissions to the current user..."
icacls $keyPath /inheritance:r | Out-Null
icacls $keyPath /grant:r "$($env:USERNAME):(R)" | Out-Null

# 3) write ~/.cttc/connection.json -------------------------------------------
# Absolute path resolved from wherever this bundle actually got extracted to
# -- connection.json itself needs a concrete path, not a relative one.
New-Item -ItemType Directory -Force -Path $cttcDir | Out-Null
$config = @{
  mode        = "ssh-tunnel"
  ssh_target  = "oliviersteck@192.168.1.138"
  ssh_key     = $keyPath
  remote_port = 8765
} | ConvertTo-Json

# Windows PowerShell's -Encoding UTF8 writes a byte-order-mark; Node's
# JSON.parse() does not strip a leading BOM and would fail to parse this
# file with a cryptic "invalid JSON" error. Write BOM-less UTF-8 explicitly.
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($configPath, $config, $utf8NoBom)
Write-Host "Wrote $configPath"

# 4) install deps + launch ----------------------------------------------------
Write-Host ""
Write-Host "Installing dependencies (first run only, this can take a minute)..."
Push-Location $appDir
try {
  npm install
  if ($LASTEXITCODE -ne 0) { Fail "npm install failed (see output above)." }

  Write-Host ""
  Write-Host "Starting CTTC -- connecting to 192.168.1.138 over SSH..." -ForegroundColor Cyan
  npm start
} finally {
  Pop-Location
}
