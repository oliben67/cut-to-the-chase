# CTTC — Windows client test bundle

This tests the core promise of CTTC's remote-server mode: **this Windows
machine needs no Docker, no Python, no `uv` at all.** It's a thin client
that connects over SSH to a CTTC server already running as a container on
a separate Linux host (`192.168.1.138`), which does all the Docker work.

Background: [docs/architecture/remote-server.md](https://github.com/oliben67/cut-to-the-chase/blob/feature/remote-server-ssh-tunnel/docs/architecture/remote-server.md)
in the main repo.

## What's in this folder

```
app/                    the Electron client (no server/, no demo/ — not needed here)
keys/cttc_windows_test   a dedicated SSH keypair, already authorized on 192.168.1.138
                          (added to that host's ~/.ssh/authorized_keys for this test only)
setup.ps1                does everything below in one step
README-WINDOWS-TEST.md   this file
```

## Prerequisites

- **Node.js** (LTS) — <https://nodejs.org/>. `setup.ps1` checks for this and
  tells you if it's missing.
- **OpenSSH client** — ships with Windows 10 (1809+) and 11, usually already
  enabled. If `setup.ps1` says it's missing: Settings → Apps → Optional
  features → Add a feature → "OpenSSH Client" (or, as Administrator:
  `Add-WindowsCapability -Online -Name OpenSSH.Client~~~~0.0.1.0`).

## Run it

Right-click **`setup.ps1`** → **Run with PowerShell**. (If Windows blocks it
as an unsigned script, run from a PowerShell prompt instead:
`powershell -ExecutionPolicy Bypass -File .\setup.ps1`)

It will:
1. Check Node.js/npm and ssh are on `PATH`.
2. Lock down the bundled private key's file permissions to the current user
   only (Windows OpenSSH refuses a key that isn't restricted this way).
3. Write `%USERPROFILE%\.cttc\connection.json` pointing at 192.168.1.138,
   using that key.
4. `npm install` (first run only — downloads Electron).
5. `npm start` — opens the app. It should connect through the tunnel and
   look and behave identically to a normal local install; the toolbar's
   **＋ Add sources** dialog will list the real containers running on
   192.168.1.138.

## What to check

- The app window opens without an error dialog (a connection failure shows
  as a native error box — "could not reach `oliviersteck@192.168.1.138` via
  ssh" or similar).
- **＋ Add sources** lists real containers on the remote host.
- Adding one and watching data actually populate the charts/log panel.
- **✂ Capture metrics** and **📂 Load metrics** — these now move bytes over
  HTTP rather than assuming a shared filesystem, so they're worth checking
  specifically on this machine, which definitely doesn't share one with the
  server.

## Cleanup afterward

This key is scoped to this test only. To revoke it, on the server:
```sh
ssh 192.168.1.138
# edit ~/.ssh/authorized_keys and remove the line ending "cttc-windows-test"
```
